export default function UserRegisterPage() {
  return <div>This is a page where you register</div>;
}
