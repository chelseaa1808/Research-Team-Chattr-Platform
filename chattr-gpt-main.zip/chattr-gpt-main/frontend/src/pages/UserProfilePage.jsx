export default function UserProfilePage() {
  return <div>This is a page where you can see your profile</div>;
}
